# WordPress MySQL database migration
#
# Generated: Monday 15. February 2021 10:03 UTC
# Hostname: localhost
# Database: `liminal_lab`
# URL: //localhost:81/LiminalLab
# Path: /Applications/MAMP/htdocs/LiminalLab
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, customize_changeset, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un comentarista del WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-02-11 13:43:49', '2021-02-11 11:43:49', 'Hola, això és un comentari.\nPer començar a moderar, editar i suprimir comentaris, visiteu la pantalla dels comentaris al tauler.\nEls avatars dels comentaris vénen des del <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:81/LiminalLab', 'yes'),
(2, 'home', 'http://localhost:81/LiminalLab', 'yes'),
(3, 'blogname', 'Liminal Lab', 'yes'),
(4, 'blogdescription', 'Un altre lloc gestionat amb el WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'joan.parellada@maneko.es', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j \\d\\e F \\d\\e Y', 'yes'),
(24, 'time_format', 'G:i', 'yes'),
(25, 'links_updated_date_format', 'j \\d\\e F \\d\\e Y G:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:125:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:14:"custom_type/?$";s:31:"index.php?post_type=custom_type";s:44:"custom_type/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=custom_type&feed=$matches[1]";s:39:"custom_type/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=custom_type&feed=$matches[1]";s:31:"custom_type/page/([0-9]{1,})/?$";s:49:"index.php?post_type=custom_type&paged=$matches[1]";s:52:"custom-slug/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?custom_cat=$matches[1]&feed=$matches[2]";s:47:"custom-slug/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?custom_cat=$matches[1]&feed=$matches[2]";s:28:"custom-slug/([^/]+)/embed/?$";s:43:"index.php?custom_cat=$matches[1]&embed=true";s:40:"custom-slug/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?custom_cat=$matches[1]&paged=$matches[2]";s:22:"custom-slug/([^/]+)/?$";s:32:"index.php?custom_cat=$matches[1]";s:51:"custom_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?custom_tag=$matches[1]&feed=$matches[2]";s:46:"custom_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?custom_tag=$matches[1]&feed=$matches[2]";s:27:"custom_tag/([^/]+)/embed/?$";s:43:"index.php?custom_tag=$matches[1]&embed=true";s:39:"custom_tag/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?custom_tag=$matches[1]&paged=$matches[2]";s:21:"custom_tag/([^/]+)/?$";s:32:"index.php?custom_tag=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:39:"custom_type/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"custom_type/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"custom_type/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"custom_type/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"custom_type/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"custom_type/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:28:"custom_type/([^/]+)/embed/?$";s:44:"index.php?custom_type=$matches[1]&embed=true";s:32:"custom_type/([^/]+)/trackback/?$";s:38:"index.php?custom_type=$matches[1]&tb=1";s:52:"custom_type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?custom_type=$matches[1]&feed=$matches[2]";s:47:"custom_type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?custom_type=$matches[1]&feed=$matches[2]";s:40:"custom_type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?custom_type=$matches[1]&paged=$matches[2]";s:47:"custom_type/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?custom_type=$matches[1]&cpage=$matches[2]";s:36:"custom_type/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?custom_type=$matches[1]&page=$matches[2]";s:28:"custom_type/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"custom_type/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"custom_type/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"custom_type/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"custom_type/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"custom_type/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '2', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:66:"C:\\MAMP\\htdocs\\Liminal Lab/wp-content/themes/liminal-lab/style.css";i:1;s:0:"";}', 'no'),
(40, 'template', 'liminal-lab', 'yes'),
(41, 'stylesheet', 'liminal-lab', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '5', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1628595829', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'WPLANG', 'ca', 'yes'),
(102, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}s:8:"sidebar1";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:13:"array_version";i:3;}', 'yes'),
(108, 'cron', 'a:7:{i:1613385831;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1613389430;a:3:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1613389431;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1613389434;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1613389436;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1613735030;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(109, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'recovery_keys', 'a:0:{}', 'yes'),
(132, 'can_compress_scripts', '0', 'no'),
(149, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:24:"joan.parellada@maneko.es";s:7:"version";s:5:"5.6.1";s:9:"timestamp";i:1613043865;}', 'no'),
(152, 'finished_updating_comment_type', '1', 'yes'),
(153, 'theme_mods_twentytwentyone', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1613044114;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:9:"sidebar-2";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}}}}', 'yes'),
(154, 'current_theme', 'Bones (Rename Me!)', 'yes'),
(155, 'theme_mods_liminal-lab', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(156, 'theme_switched', '', 'yes'),
(159, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(160, 'recently_activated', 'a:0:{}', 'yes'),
(161, 'acf_version', '5.9.1', 'yes'),
(169, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1613383433;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1613132567:1'),
(4, 7, '_edit_lock', '1613130698:1'),
(5, 9, '_edit_lock', '1613136541:1'),
(6, 11, '_edit_lock', '1613137406:1'),
(7, 13, '_edit_lock', '1613148492:1'),
(8, 16, '_edit_lock', '1613044949:1'),
(9, 16, '_wp_trash_meta_status', 'publish'),
(10, 16, '_wp_trash_meta_time', '1613044958'),
(11, 17, '_menu_item_type', 'post_type'),
(12, 17, '_menu_item_menu_item_parent', '0'),
(13, 17, '_menu_item_object_id', '5'),
(14, 17, '_menu_item_object', 'page'),
(15, 17, '_menu_item_target', ''),
(16, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(17, 17, '_menu_item_xfn', ''),
(18, 17, '_menu_item_url', ''),
(20, 18, '_menu_item_type', 'post_type'),
(21, 18, '_menu_item_menu_item_parent', '0'),
(22, 18, '_menu_item_object_id', '13'),
(23, 18, '_menu_item_object', 'page'),
(24, 18, '_menu_item_target', ''),
(25, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(26, 18, '_menu_item_xfn', ''),
(27, 18, '_menu_item_url', ''),
(38, 20, '_menu_item_type', 'post_type'),
(39, 20, '_menu_item_menu_item_parent', '0'),
(40, 20, '_menu_item_object_id', '9'),
(41, 20, '_menu_item_object', 'page'),
(42, 20, '_menu_item_target', ''),
(43, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(44, 20, '_menu_item_xfn', ''),
(45, 20, '_menu_item_url', ''),
(47, 21, '_menu_item_type', 'post_type'),
(48, 21, '_menu_item_menu_item_parent', '0'),
(49, 21, '_menu_item_object_id', '11'),
(50, 21, '_menu_item_object', 'page'),
(51, 21, '_menu_item_target', ''),
(52, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 21, '_menu_item_xfn', ''),
(54, 21, '_menu_item_url', ''),
(56, 2, '_wp_trash_meta_status', 'publish'),
(57, 2, '_wp_trash_meta_time', '1613045110'),
(58, 2, '_wp_desired_post_slug', 'pagina-exemple'),
(59, 25, '_edit_last', '1'),
(60, 25, '_edit_lock', '1613131376:1'),
(61, 5, '_wp_page_template', 'page-intro.php'),
(62, 5, '_edit_last', '1'),
(63, 5, 'text1', 'Liminal Lab es un espacio que quiere facilitar el cambio, la evolución y el crecimiento de los equipos en el entorno laboral'),
(64, 5, '_text1', 'field_60251fd60de27'),
(65, 5, 'text2', 'La auténtica aventura liminal atraviesa el umbral de lo conocido y trasciende el límite para disfrutar del camino teniendo claro el itinerario. Un proceso que propone tres fases: 1. Adaptarse al modo “no saber” para encontrar un diagnóstico con la mente abierta. Es el momento de prepararse para crear algo nuevo; \r\n2. Explorar las cualidades e iniciativas novedosas que permitan desarrollar un mapa de actuación; 3. Diseñar el itinerario para una nueva identidad social e individual.'),
(66, 5, '_text2', 'field_6025205f0de28'),
(67, 5, 'text3', 'Trabajamos a partir del PDA Assessment, una metodología precisa y efectiva que permite describir y estudiar el perfil de comportamiento de las personas, identifica talentos, habilidades, motivaciones y puntos fuertes, descubre las áreas donde existe mayor potencial y los puntos ciegos que quedan inadvertidos e impiden un desarrollo eficaz y satisfactorio. PDA Assessment es una herramienta rápida e intuitiva que agiliza el proceso organizativo y optimiza el tiempo en la elaboración de informes tanto individuales como de equipos.'),
(68, 5, '_text3', 'field_602520840de29'),
(69, 5, 'text4', 'Un diagnóstico, un mapa y un itinerario que permite alcanzar el equilibrio y la armonía del sistema. Así como mejorar la coordinación y la conexión de los equipos y proporcionar seguridad y satisfacción en el desarrollo de su propio talento y el bienestar de la organización.'),
(70, 5, '_text4', 'field_602520930de2a'),
(71, 23, 'text1', 'Liminal Lab es un espacio que quiere facilitar el cambio, la evolución y el crecimiento de los equipos en el entorno laboral'),
(72, 23, '_text1', 'field_60251fd60de27'),
(73, 23, 'text2', 'La auténtica aventura liminal atraviesa el umbral de lo conocido y trasciende el límite para disfrutar del camino teniendo claro el itinerario. Un proceso que propone tres fases: 1. Adaptarse al modo “no saber” para encontrar un diagnóstico con la mente abierta. Es el momento de prepararse para crear algo nuevo; \r\n2. Explorar las cualidades e iniciativas novedosas que permitan desarrollar un mapa de actuación; 3. Diseñar el itinerario para una nueva identidad social e individual.'),
(74, 23, '_text2', 'field_6025205f0de28'),
(75, 23, 'text3', 'Trabajamos a partir del PDA Assessment, una metodología precisa y efectiva que permite describir y estudiar el perfil de comportamiento de las personas, identifica talentos, habilidades, motivaciones y puntos fuertes, descubre las áreas donde existe mayor potencial y los puntos ciegos que quedan inadvertidos e impiden un desarrollo eficaz y satisfactorio. PDA Assessment es una herramienta rápida e intuitiva que agiliza el proceso organizativo y optimiza el tiempo en la elaboración de informes tanto individuales como de equipos.'),
(76, 23, '_text3', 'field_602520840de29'),
(77, 23, 'text4', 'Un diagnóstico, un mapa y un itinerario que permite alcanzar el equilibrio y la armonía del sistema. Así como mejorar la coordinación y la conexión de los equipos y proporcionar seguridad y satisfacción en el desarrollo de su propio talento y el bienestar de la organización.'),
(78, 23, '_text4', 'field_602520930de2a'),
(79, 30, 'text1', 'Liminal Lab es un espacio que quiere facilitar el cambio, la evolución y el crecimiento de los equipos en el entorno laboral'),
(80, 30, '_text1', 'field_60251fd60de27'),
(81, 30, 'text2', 'La auténtica aventura liminal atraviesa el umbral de lo conocido y trasciende el límite para disfrutar del camino teniendo claro el itinerario. Un proceso que propone tres fases: 1. Adaptarse al modo “no saber” para encontrar un diagnóstico con la mente abierta. Es el momento de prepararse para crear algo nuevo; \r\n2. Explorar las cualidades e iniciativas novedosas que permitan desarrollar un mapa de actuación; 3. Diseñar el itinerario para una nueva identidad social e individual.'),
(82, 30, '_text2', 'field_6025205f0de28'),
(83, 30, 'text3', 'Trabajamos a partir del PDA Assessment, una metodología precisa y efectiva que permite describir y estudiar el perfil de comportamiento de las personas, identifica talentos, habilidades, motivaciones y puntos fuertes, descubre las áreas donde existe mayor potencial y los puntos ciegos que quedan inadvertidos e impiden un desarrollo eficaz y satisfactorio. PDA Assessment es una herramienta rápida e intuitiva que agiliza el proceso organizativo y optimiza el tiempo en la elaboración de informes tanto individuales como de equipos.'),
(84, 30, '_text3', 'field_602520840de29'),
(85, 30, 'text4', 'Un diagnóstico, un mapa y un itinerario que permite alcanzar el equilibrio y la armonía del sistema. Así como mejorar la coordinación y la conexión de los equipos y proporcionar seguridad y satisfacción en el desarrollo de su propio talento y el bienestar de la organización.'),
(86, 30, '_text4', 'field_602520930de2a'),
(87, 31, '_edit_last', '1'),
(88, 31, '_edit_lock', '1613135171:1'),
(89, 7, '_edit_last', '1'),
(90, 7, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(91, 7, '_text1', 'field_602523d1aa26e'),
(92, 7, 'text2', 'Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.'),
(93, 7, '_text2', 'field_602523e4aa26f'),
(94, 7, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(95, 7, '_circle1', 'field_6025242caa270'),
(96, 7, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(97, 7, '_circle2', 'field_6025243eaa271'),
(98, 7, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(99, 7, '_circle3', 'field_6025245daa272'),
(100, 7, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(101, 7, '_circle4', 'field_60252485aa273'),
(102, 7, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(103, 7, '_circle5', 'field_60252494aa274'),
(104, 24, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(105, 24, '_text1', 'field_602523d1aa26e'),
(106, 24, 'text2', ''),
(107, 24, '_text2', 'field_602523e4aa26f'),
(108, 24, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(109, 24, '_circle1', 'field_6025242caa270'),
(110, 24, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(111, 24, '_circle2', 'field_6025243eaa271'),
(112, 24, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(113, 24, '_circle3', 'field_6025245daa272') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(114, 24, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(115, 24, '_circle4', 'field_60252485aa273'),
(116, 24, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(117, 24, '_circle5', 'field_60252494aa274'),
(118, 9, '_wp_page_template', 'page-servicios.php'),
(119, 40, '_edit_last', '1'),
(120, 40, '_edit_lock', '1613131395:1'),
(121, 9, '_edit_last', '1'),
(122, 11, '_wp_page_template', 'page-sobre-mi.php'),
(123, 41, '_edit_last', '1'),
(124, 41, '_edit_lock', '1613136617:1'),
(125, 11, '_edit_last', '1'),
(126, 7, '_wp_page_template', 'page-para-que.php'),
(127, 42, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(128, 42, '_text1', 'field_602523d1aa26e'),
(129, 42, 'text2', 'Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.'),
(130, 42, '_text2', 'field_602523e4aa26f'),
(131, 42, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(132, 42, '_circle1', 'field_6025242caa270'),
(133, 42, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(134, 42, '_circle2', 'field_6025243eaa271'),
(135, 42, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(136, 42, '_circle3', 'field_6025245daa272'),
(137, 42, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(138, 42, '_circle4', 'field_60252485aa273'),
(139, 42, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(140, 42, '_circle5', 'field_60252494aa274'),
(141, 43, '_edit_last', '1'),
(142, 43, '_edit_lock', '1613144651:1'),
(143, 44, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(144, 44, '_text1', 'field_602523d1aa26e'),
(145, 44, 'text2', 'Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.'),
(146, 44, '_text2', 'field_602523e4aa26f'),
(147, 44, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(148, 44, '_circle1', 'field_6025242caa270'),
(149, 44, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(150, 44, '_circle2', 'field_6025243eaa271'),
(151, 44, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(152, 44, '_circle3', 'field_6025245daa272'),
(153, 44, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(154, 44, '_circle4', 'field_60252485aa273'),
(155, 44, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(156, 44, '_circle5', 'field_60252494aa274'),
(157, 13, '_wp_page_template', 'page-contacto.php'),
(158, 13, '_edit_last', '1'),
(159, 13, 'text1', 'Contacto\r\nC/ Aribau 234 1er 2na\r\n08567 Barcelona \r\ninfo@liminallab.com\r\n+34 678 899 345'),
(160, 13, '_text1', 'field_60252fffea7d8'),
(161, 14, 'text1', 'Contacto\r\nC/ Aribau 234 1er 2na\r\n08567 Barcelona \r\ninfo@liminallab.com\r\n+34 678 899 345'),
(162, 14, '_text1', 'field_60252fffea7d8'),
(163, 9, 'text1', 'Servicios. Proponemos dos procesos que se adaptan a distintas necesidades. Los cambios de paradigma de la sociedad actual precisan herramientas y procesos que afloren la información, incentiven la creatividad de los equipos de trabajo e innoven en la forma de afrontar los retos y objetivos tanto de los profesionales como de las organizaciones.'),
(164, 9, '_text1', 'field_60252f2486733'),
(165, 9, 'text_circle', 'SÉ EL DUEÑO DE TUS DECISIONES'),
(166, 9, '_text_circle', 'field_60252f454ff3d'),
(167, 9, 'text_slider_0_text', '1. Liminal inception\r\n\r\nCómo evolucionar y disfrutar del itinerario y de una carrera profesional.\r\nCómo pasar del desencanto a encontrar tu lugar y crecer profesionalmente.\r\n \r\n¿Cuál es tu perfil de conducta natural y cómo te adaptas al entorno laboral? \r\n¿Qué es lo que se te da mejor y qué te cuesta más? \r\n¿Qué te motiva y qué no te va nada? \r\n¿A qué le deberías dedicar mayor atención y esfuerzo?\r\n\r\nObtén información para enfocar tu carrera y disfrutar del trayecto. Para aquellos jóvenes profesionales que iniciáis vuestra andadura laboral. Tanto si habéis finalizado vuestros estudios y aún no trabajáis, como si vivís vuestras primeras experiencias laborales, dentro de una organización o por cuenta propia.'),
(168, 9, '_text_slider_0_text', 'field_60252f85a6d4f'),
(169, 9, 'text_slider', '1'),
(170, 9, '_text_slider', 'field_60252f70a6d4e'),
(171, 51, 'text1', 'Servicios. Proponemos dos procesos que se adaptan a distintas necesidades. Los cambios de paradigma de la sociedad actual precisan herramientas y procesos que afloren la información, incentiven la creatividad de los equipos de trabajo e innoven en la forma de afrontar los retos y objetivos tanto de los profesionales como de las organizaciones.'),
(172, 51, '_text1', 'field_60252f2486733'),
(173, 51, 'text_circle', 'SÉ EL DUEÑO DE TUS DECISIONES'),
(174, 51, '_text_circle', 'field_60252f454ff3d'),
(175, 51, 'text_slider_0_text', '1. Liminal inception\r\n\r\nCómo evolucionar y disfrutar del itinerario y de una carrera profesional.\r\nCómo pasar del desencanto a encontrar tu lugar y crecer profesionalmente.\r\n \r\n¿Cuál es tu perfil de conducta natural y cómo te adaptas al entorno laboral? \r\n¿Qué es lo que se te da mejor y qué te cuesta más? \r\n¿Qué te motiva y qué no te va nada? \r\n¿A qué le deberías dedicar mayor atención y esfuerzo?\r\n\r\nObtén información para enfocar tu carrera y disfrutar del trayecto. Para aquellos jóvenes profesionales que iniciáis vuestra andadura laboral. Tanto si habéis finalizado vuestros estudios y aún no trabajáis, como si vivís vuestras primeras experiencias laborales, dentro de una organización o por cuenta propia.'),
(176, 51, '_text_slider_0_text', 'field_60252f85a6d4f'),
(177, 51, 'text_slider', '1'),
(178, 51, '_text_slider', 'field_60252f70a6d4e'),
(179, 11, 'text1', 'SOBRE MI. Me apasionan la estrategia, la comunicación, la creatividad y sobretodo los equipos y las organizaciones. Tras más de 30 años de carrera profesional en agencias multinacionales de publicidad he trabajado para grandes marcas como Nestlé, Unilever, Mondelez, Deutsche Bank y Reckitt Benckiser, entre otras. Los últimos 20 años de mi carrera en agencias he dirigido equipos y liderado organizaciones formando parte de los boards de dirección.'),
(180, 11, '_text1', 'field_60252fd3f78b5'),
(181, 12, 'text1', 'SOBRE MI. Me apasionan la estrategia, la comunicación, la creatividad y sobretodo los equipos y las organizaciones. Tras más de 30 años de carrera profesional en agencias multinacionales de publicidad he trabajado para grandes marcas como Nestlé, Unilever, Mondelez, Deutsche Bank y Reckitt Benckiser, entre otras. Los últimos 20 años de mi carrera en agencias he dirigido equipos y liderado organizaciones formando parte de los boards de dirección.'),
(182, 12, '_text1', 'field_60252fd3f78b5'),
(183, 7, 'marquee', 'Repensar organizaciones y equipos para potenc'),
(184, 7, '_marquee', 'field_60266b9f6322c'),
(185, 44, 'marquee', 'Repensar organizaciones y equipos para potenc'),
(186, 44, '_marquee', 'field_60266b9f6322c'),
(187, 7, '_wp_trash_meta_status', 'publish'),
(188, 7, '_wp_trash_meta_time', '1613130846'),
(189, 7, '_wp_desired_post_slug', 'para-que'),
(190, 53, '_edit_lock', '1613130717:1'),
(191, 54, '_edit_lock', '1613135404:1'),
(192, 54, '_wp_page_template', 'page-para-que.php'),
(193, 54, '_edit_last', '1'),
(194, 54, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(195, 54, '_text1', 'field_602523d1aa26e'),
(196, 54, 'text2', 'Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.'),
(197, 54, '_text2', 'field_602523e4aa26f'),
(198, 54, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(199, 54, '_circle1', 'field_6025242caa270'),
(200, 54, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(201, 54, '_circle2', 'field_6025243eaa271'),
(202, 54, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(203, 54, '_circle3', 'field_6025245daa272'),
(204, 54, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(205, 54, '_circle4', 'field_60252485aa273'),
(206, 54, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(207, 54, '_circle5', 'field_60252494aa274'),
(208, 54, 'marquee', 'Repensar organizaciones y equipos para potenc'),
(209, 54, '_marquee', 'field_60266b9f6322c'),
(210, 55, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(211, 55, '_text1', 'field_602523d1aa26e'),
(212, 55, 'text2', 'Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.'),
(213, 55, '_text2', 'field_602523e4aa26f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(214, 55, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(215, 55, '_circle1', 'field_6025242caa270'),
(216, 55, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(217, 55, '_circle2', 'field_6025243eaa271'),
(218, 55, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(219, 55, '_circle3', 'field_6025245daa272'),
(220, 55, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(221, 55, '_circle4', 'field_60252485aa273'),
(222, 55, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(223, 55, '_circle5', 'field_60252494aa274'),
(224, 55, 'marquee', 'Repensar organizaciones y equipos para potenc'),
(225, 55, '_marquee', 'field_60266b9f6322c'),
(226, 56, '_menu_item_type', 'post_type'),
(227, 56, '_menu_item_menu_item_parent', '0'),
(228, 56, '_menu_item_object_id', '54'),
(229, 56, '_menu_item_object', 'page'),
(230, 56, '_menu_item_target', ''),
(231, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(232, 56, '_menu_item_xfn', ''),
(233, 56, '_menu_item_url', ''),
(234, 54, 'marquee2', 'LAS METAS SE CONSIGUEN, SOBRE TODO, SI SE DISFRUTA DEL CAMINO'),
(235, 54, '_marquee2', 'field_60267dc207360'),
(236, 58, 'text1', 'PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.'),
(237, 58, '_text1', 'field_602523d1aa26e'),
(238, 58, 'text2', 'Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.'),
(239, 58, '_text2', 'field_602523e4aa26f'),
(240, 58, 'circle1', 'OPTIMIZAR  LA GESTIÓN DE EQUIPOS'),
(241, 58, '_circle1', 'field_6025242caa270'),
(242, 58, 'circle2', 'POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS'),
(243, 58, '_circle2', 'field_6025243eaa271'),
(244, 58, 'circle3', 'REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR'),
(245, 58, '_circle3', 'field_6025245daa272'),
(246, 58, 'circle4', 'FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN'),
(247, 58, '_circle4', 'field_60252485aa273'),
(248, 58, 'circle5', 'RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO'),
(249, 58, '_circle5', 'field_60252494aa274'),
(250, 58, 'marquee', 'Repensar organizaciones y equipos para potenc'),
(251, 58, '_marquee', 'field_60266b9f6322c'),
(252, 58, 'marquee2', 'LAS METAS SE CONSIGUEN, SOBRE TODO, SI SE DISFRUTA DEL CAMINO'),
(253, 58, '_marquee2', 'field_60267dc207360'),
(254, 13, 'instagram', 'https://www.instagram.com/'),
(255, 13, '_instagram', 'field_6026a292b640a'),
(256, 13, 'facebook', 'https://www.facebook.com'),
(257, 13, '_facebook', 'field_6026a2a9b640b'),
(258, 13, 'linkedin', 'https://www.linkedin.com'),
(259, 13, '_linkedin', 'field_6026a2b3b640c'),
(260, 13, 'twitter', 'https://www.twitter.com'),
(261, 13, '_twitter', 'field_6026a2c1b640d'),
(262, 64, 'text1', 'Contacto\r\nC/ Aribau 234 1er 2na\r\n08567 Barcelona \r\ninfo@liminallab.com\r\n+34 678 899 345'),
(263, 64, '_text1', 'field_60252fffea7d8'),
(264, 64, 'instagram', 'https://www.instagram.com/'),
(265, 64, '_instagram', 'field_6026a292b640a'),
(266, 64, 'facebook', 'https://www.facebook.com'),
(267, 64, '_facebook', 'field_6026a2a9b640b'),
(268, 64, 'linkedin', 'https://www.linkedin.com'),
(269, 64, '_linkedin', 'field_6026a2b3b640c'),
(270, 64, 'twitter', 'https://www.twitter.com'),
(271, 64, '_twitter', 'field_6026a2c1b640d'),
(272, 65, '_edit_lock', '1613148506:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-02-11 13:43:49', '2021-02-11 11:43:49', '<!-- wp:paragraph -->\n<p>Benvinguts al WordPress. Aquest és la primera entrada. Editeu-la o suprimiu-la, i aleshores comenceu a escriure!</p>\n<!-- /wp:paragraph -->', 'Hola, món!', '', 'publish', 'open', 'open', '', 'hola-mon', '', '', '2021-02-11 13:43:49', '2021-02-11 11:43:49', '', 0, 'http://localhost:81/Liminal%20Lab/?p=1', 0, 'post', '', 1),
(2, 1, '2021-02-11 13:43:49', '2021-02-11 11:43:49', '<!-- wp:paragraph -->\n<p>Aquest és una pàgina d\'exemple. És diferent d\'una entrada del blog perquè es mantindrà en un lloc i apareixerà a la navegació del lloc (a la majoria de temes). Molta gent comença amb la pàgina «Quant a», que els presenta als potencials visitants del lloc web. Podria dir alguna cosa així:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hola! Sóc un missatger amb bicicleta de dia, aspirant a actor de nit i aquesta és la meva web. Visc a Los Angeles, tinc un gran gos de nom Pep i m\'agrada la pinya colada. (I em pillarà la pluja.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... o alguna cosa així:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La companyia Aparells XYZ es va crear el 1971, i ha estat proporcionant aparells de qualitat al públic des de llavors. Ubicada a Gotham City, XYZ dóna treball a més de 2.000 persones i fa tota mena d\'accions meravelloses per a la comunitat de Gotham.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Com a usuari nou del WordPress, hauríeu d\'anar al <a href="http://localhost:81/Liminal%20Lab/wp-admin/">tauler</a> per a suprimir aquesta pàgina i crear pàgines noves de contingut. Divertiu-vos!</p>\n<!-- /wp:paragraph -->', 'Pàgina d\'exemple', '', 'trash', 'closed', 'open', '', 'pagina-exemple__trashed', '', '', '2021-02-11 14:05:10', '2021-02-11 12:05:10', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-02-11 13:43:49', '2021-02-11 11:43:49', '<!-- wp:heading --><h2>Qui som</h2><!-- /wp:heading --><!-- wp:paragraph --><p>La nostra adreça web és: http://localhost:81/Liminal%20Lab.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quines dades personals recollim i per què</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Comentaris</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Quan els visitants deixen comentaris a la web, recollim les dades que es mostren al formulari de contacte, així com l\'adreça IP del visitant i la cadena de l\'agent de l\'usuari del navegador per ajudar a la detecció de missatges brossa.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Una cadena anonimitzada creada a partir del correu electrònic (també anomenat un hash) pot proporcionar-se al servei Gravatar per veure si l\'esteu usant. La política de privadesa del servei Gravatar està disponible aquí: https://automattic.com/privacy/. Una vegada aprovat el comentari, la imatge del vostre perfil és visible al públic al context del comentari.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Mèdia</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Si pugeu imatges al lloc web, heu d\'evitar pujar imatges que incloguin dades de geolocalització (EXIF GPS) incrustades. Els visitants del lloc web poden descarregar i extreure qualsevol informació de les imatges de la web.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Formularis de contacte</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Galetes</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Si deixeu un comentari en la pàgina web, podeu optar per desar el nom, l\'adreça de correu electrònic i la pàgina web en les galetes. Això és per la vostra comoditat perquè no hàgeu d\'emplenar les dades de nou quan feu un altre comentari. Aquestes galetes duraran un any.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si teniu un compte i inicieu sessió en aquesta pàgina web, es definirà una galeta temporal per determinar si el navegador accepta galetes. Aquesta galeta no conté dades personals i es descartarà quan tanqueu el navegador.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Quan inicieu sessió, també es configuraran diverses galetes per desar la informació d\'inici de sessió i les opcions de visualització de la pantalla. Les galeres d\'inici de sessió duren dos dies, i les galetes de les opcions de pantalla duren un any. Si seleccioneu &quot;Recordeu-me&quot;, l\'inici de sessió persistirà durant dues setmanes. Si finalitzeu la sessió, les galetes d\'inici de sessió seran suprimides.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si editeu o publiqueu un article, una galeta addicional es desarà al navegador. Aquesta galeta no inclou dades personals i simplement indica l\'identificador de l\'entrada que acabeu d\'editar. Expira després d\'1 dia.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Contingut incrustat d\'altres llocs web</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Els articles en aquesta pàgina web inclou contingut incrustat (per exemple, vídeos, imatges, articles, etc.). El contingut incrustat des d\'altres pàgines web es comporta exactament de la mateixa manera com si el visitant estigués visitant l\'altra pàgina web.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Aquestes pàgines web poden recollir dades sobre vós, fer servir galetes, incrustar seguiment addicional de terceres parts, i monitorar la interacció amb el contingut incrustat, incloent-hi la traça de la interacció amb el contingut incrustat si teniu un compte i heu iniciat sessió en aquesta pàgina web.</p><!-- /wp:paragraph --><!-- wp:heading {"level":3} --><h3>Analítiques</h3><!-- /wp:heading --><!-- wp:heading --><h2>Amb qui compartim les vostres dades</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si sol·liciteu un reinici de contrasenya, l\'adreça UP s\'inclourà en el correu electrònic de reinicialització.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quant de temps retenim les dades</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si deixeu un comentari, el comentari i les seves dades meta es retenen indefinidament. Això és per poder reconèixer i aprovar automàticament qualsevol comentari de seguiment en lloc de mantenir-los en la cua de moderació.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Per als usuaris que es registren en la web (si hi ha), també emmagatzemem la informació personal que proporcionen al seu perfil d\'usuari. Tots els usuaris poden veure, editar o suprimir la seva informació personal en qualsevol moment (excepte que no poden canviar el seu nom d\'usuari). Els administradors de la pàgina web poden també editar aquesta informació. </p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quins drets teniu sobre les vostres dades</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Si teniu un compte en aquest lloc web o hi heu deixat comentaris, podeu demanar que us enviem un fitxer d\'exportació de les vostres dades personals, incloent-hi totes les dades que ens hàgeu proporcionat. També podeu demanar que esborrem qualsevol dada personal vostra que tinguem. Això no inclou les dades que estiguem obligats a conservar amb propòsits administratius, legals o de seguretat.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>On enviem les vostres dades</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Els comentaris dels visitants han de ser comprovats mitjançant un servei de detecció de brossa automatitzat.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Informació de contacte</h2><!-- /wp:heading --><!-- wp:heading --><h2>Informació addicional</h2><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Com protegim les vostres dades</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Quins procediments d\'incompliment de dades tenim en el lloc</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>De quins tercers rebem dades</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Quina presa de decisions automatitzada i/o perfil fem amb les dades de l\'usuari</h3><!-- /wp:heading --><!-- wp:heading {"level":3} --><h3>Requisits de divulgació reglamentària de la indústria</h3><!-- /wp:heading -->', 'Política de privadesa ', '', 'draft', 'closed', 'open', '', 'política-de-privadesa', '', '', '2021-02-11 13:43:49', '2021-02-11 11:43:49', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-02-11 13:43:56', '0000-00-00 00:00:00', '', 'Esborrany automàtic', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-02-11 13:43:56', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/Liminal%20Lab/?p=4', 0, 'post', '', 0),
(5, 1, '2021-02-11 13:54:11', '2021-02-11 11:54:11', '', 'INTRO', '', 'publish', 'closed', 'closed', '', 'intro', '', '', '2021-02-12 14:22:47', '2021-02-12 12:22:47', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=5', 0, 'page', '', 0),
(6, 1, '2021-02-11 13:54:11', '2021-02-11 11:54:11', '', 'Intro', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-02-11 13:54:11', '2021-02-11 11:54:11', '', 5, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2021-02-11 13:54:32', '2021-02-11 11:54:32', '', 'PARA QUÉ', '', 'trash', 'closed', 'closed', '', 'para-que__trashed', '', '', '2021-02-12 13:54:06', '2021-02-12 11:54:06', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=7', 0, 'page', '', 0),
(8, 1, '2021-02-11 13:54:32', '2021-02-11 11:54:32', '', 'PARA QUÉ', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-02-11 13:54:32', '2021-02-11 11:54:32', '', 7, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/7-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2021-02-11 13:54:43', '2021-02-11 11:54:43', '', 'SERVICIOS', '', 'publish', 'closed', 'closed', '', 'servicios', '', '', '2021-02-12 14:23:00', '2021-02-12 12:23:00', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=9', 2, 'page', '', 0),
(10, 1, '2021-02-11 13:54:43', '2021-02-11 11:54:43', '', 'SERVICIOS', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2021-02-11 13:54:43', '2021-02-11 11:54:43', '', 9, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2021-02-11 13:54:53', '2021-02-11 11:54:53', '', 'SOBRE MÍ', '', 'publish', 'closed', 'closed', '', 'sobre-mi', '', '', '2021-02-12 14:23:06', '2021-02-12 12:23:06', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=11', 3, 'page', '', 0),
(12, 1, '2021-02-11 13:54:53', '2021-02-11 11:54:53', '', 'SOBRE MÍ', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2021-02-11 13:54:53', '2021-02-11 11:54:53', '', 11, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2021-02-11 13:55:01', '2021-02-11 11:55:01', '', 'CONTACTO', '', 'publish', 'closed', 'closed', '', 'contacto', '', '', '2021-02-12 17:47:55', '2021-02-12 15:47:55', '', 0, 'http://localhost:81/Liminal%20Lab/?page_id=13', 4, 'page', '', 0),
(14, 1, '2021-02-11 13:55:01', '2021-02-11 11:55:01', '', 'CONTACTO', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2021-02-11 13:55:01', '2021-02-11 11:55:01', '', 13, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2021-02-11 13:55:10', '2021-02-11 11:55:10', '', 'INTRO', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-02-11 13:55:10', '2021-02-11 11:55:10', '', 5, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/5-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2021-02-11 14:02:38', '2021-02-11 12:02:38', '{"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2021-02-11 11:55:59"},"page_on_front":{"value":"5","type":"option","user_id":1,"date_modified_gmt":"2021-02-11 11:55:59"}}', '', '', 'trash', 'closed', 'closed', '', 'dbeadc3e-e584-4c01-b45f-f031a0d085a9', '', '', '2021-02-11 14:02:38', '2021-02-11 12:02:38', '', 0, 'http://localhost:81/Liminal%20Lab/?p=16', 0, 'customize_changeset', '', 0),
(17, 1, '2021-02-11 14:03:14', '2021-02-11 12:03:14', ' ', '', '', 'publish', 'closed', 'closed', '', '17', '', '', '2021-02-12 14:18:45', '2021-02-12 12:18:45', '', 0, 'http://localhost:81/Liminal%20Lab/?p=17', 1, 'nav_menu_item', '', 0),
(18, 1, '2021-02-11 14:03:14', '2021-02-11 12:03:14', ' ', '', '', 'publish', 'closed', 'closed', '', '18', '', '', '2021-02-12 14:18:45', '2021-02-12 12:18:45', '', 0, 'http://localhost:81/Liminal%20Lab/?p=18', 5, 'nav_menu_item', '', 0),
(20, 1, '2021-02-11 14:03:14', '2021-02-11 12:03:14', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2021-02-12 14:18:45', '2021-02-12 12:18:45', '', 0, 'http://localhost:81/Liminal%20Lab/?p=20', 3, 'nav_menu_item', '', 0),
(21, 1, '2021-02-11 14:03:14', '2021-02-11 12:03:14', ' ', '', '', 'publish', 'closed', 'closed', '', '21', '', '', '2021-02-12 14:18:45', '2021-02-12 12:18:45', '', 0, 'http://localhost:81/Liminal%20Lab/?p=21', 4, 'nav_menu_item', '', 0),
(22, 1, '2021-02-11 14:05:10', '2021-02-11 12:05:10', '<!-- wp:paragraph -->\n<p>Aquest és una pàgina d\'exemple. És diferent d\'una entrada del blog perquè es mantindrà en un lloc i apareixerà a la navegació del lloc (a la majoria de temes). Molta gent comença amb la pàgina «Quant a», que els presenta als potencials visitants del lloc web. Podria dir alguna cosa així:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hola! Sóc un missatger amb bicicleta de dia, aspirant a actor de nit i aquesta és la meva web. Visc a Los Angeles, tinc un gran gos de nom Pep i m\'agrada la pinya colada. (I em pillarà la pluja.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... o alguna cosa així:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La companyia Aparells XYZ es va crear el 1971, i ha estat proporcionant aparells de qualitat al públic des de llavors. Ubicada a Gotham City, XYZ dóna treball a més de 2.000 persones i fa tota mena d\'accions meravelloses per a la comunitat de Gotham.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Com a usuari nou del WordPress, hauríeu d\'anar al <a href="http://localhost:81/Liminal%20Lab/wp-admin/">tauler</a> per a suprimir aquesta pàgina i crear pàgines noves de contingut. Divertiu-vos!</p>\n<!-- /wp:paragraph -->', 'Pàgina d\'exemple', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-02-11 14:05:10', '2021-02-11 12:05:10', '', 2, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/2-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2021-02-11 14:07:39', '2021-02-11 12:07:39', '<!-- wp:paragraph -->\n<p>page intro</p>\n<!-- /wp:paragraph -->', 'INTRO', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-02-11 14:07:39', '2021-02-11 12:07:39', '', 5, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/5-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2021-02-11 14:08:38', '2021-02-11 12:08:38', '<!-- wp:paragraph -->\n<p>page para qué</p>\n<!-- /wp:paragraph -->', 'PARA QUÉ', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-02-11 14:08:38', '2021-02-11 12:08:38', '', 7, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/7-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2021-02-11 14:18:48', '2021-02-11 12:18:48', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-intro.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'INTRO', 'intro', 'publish', 'closed', 'closed', '', 'group_60251f22b5f27', '', '', '2021-02-12 14:05:18', '2021-02-12 12:05:18', '', 0, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field-group&#038;p=25', 0, 'acf-field-group', '', 0),
(26, 1, '2021-02-11 14:18:48', '2021-02-11 12:18:48', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:125:"Liminal Lab es un espacio que quiere facilitar el cambio, la evolución y el crecimiento de los equipos en el entorno laboral";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'text1', 'text1', 'publish', 'closed', 'closed', '', 'field_60251fd60de27', '', '', '2021-02-11 14:18:48', '2021-02-11 12:18:48', '', 25, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=26', 0, 'acf-field', '', 0),
(27, 1, '2021-02-11 14:18:48', '2021-02-11 12:18:48', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:493:"La auténtica aventura liminal atraviesa el umbral de lo conocido y trasciende el límite para disfrutar del camino teniendo claro el itinerario. Un proceso que propone tres fases: 1. Adaptarse al modo “no saber” para encontrar un diagnóstico con la mente abierta. Es el momento de prepararse para crear algo nuevo; \r\n2. Explorar las cualidades e iniciativas novedosas que permitan desarrollar un mapa de actuación; 3. Diseñar el itinerario para una nueva identidad social e individual.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'text2', 'text2', 'publish', 'closed', 'closed', '', 'field_6025205f0de28', '', '', '2021-02-11 14:18:48', '2021-02-11 12:18:48', '', 25, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=27', 1, 'acf-field', '', 0),
(28, 1, '2021-02-11 14:18:48', '2021-02-11 12:18:48', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:537:"Trabajamos a partir del PDA Assessment, una metodología precisa y efectiva que permite describir y estudiar el perfil de comportamiento de las personas, identifica talentos, habilidades, motivaciones y puntos fuertes, descubre las áreas donde existe mayor potencial y los puntos ciegos que quedan inadvertidos e impiden un desarrollo eficaz y satisfactorio. PDA Assessment es una herramienta rápida e intuitiva que agiliza el proceso organizativo y optimiza el tiempo en la elaboración de informes tanto individuales como de equipos.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'text3', 'text3', 'publish', 'closed', 'closed', '', 'field_602520840de29', '', '', '2021-02-11 14:18:48', '2021-02-11 12:18:48', '', 25, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=28', 2, 'acf-field', '', 0),
(29, 1, '2021-02-11 14:18:48', '2021-02-11 12:18:48', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:282:"Un diagnóstico, un mapa y un itinerario que permite alcanzar el equilibrio y la armonía del sistema. Así como mejorar la coordinación y la conexión de los equipos y proporcionar seguridad y satisfacción en el desarrollo de su propio talento y el bienestar de la organización.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'text4', 'text4', 'publish', 'closed', 'closed', '', 'field_602520930de2a', '', '', '2021-02-11 14:18:48', '2021-02-11 12:18:48', '', 25, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=29', 3, 'acf-field', '', 0),
(30, 1, '2021-02-11 14:19:30', '2021-02-11 12:19:30', '', 'INTRO', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-02-11 14:19:30', '2021-02-11 12:19:30', '', 5, 'http://localhost:81/Liminal%20Lab/index.php/2021/02/11/5-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"page-para-que.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'PARA QUÉ', 'para-que', 'publish', 'closed', 'closed', '', 'group_602523aa46beb', '', '', '2021-02-12 15:08:34', '2021-02-12 13:08:34', '', 0, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field-group&#038;p=31', 0, 'acf-field-group', '', 0),
(32, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:615:"PARA QUE? En el trabajo se puede disfrutar: ese objetivo no es una quimera o una ilusión. Es posible disfrutar con lo que hacemos y revertir esa satisfacción en la organización a la que pertenecemos. Se trata de convertir la necesidad de trabajar en una actividad que nos llene y nos complete de forma plenamente gratificante. Tanto el estrés como los obstáculos imprevistos son parte de nosotros pero también parte del aprendizaje para optimizar, disfrutar, descubrir las oportunidades y evitar la pérdida de energía en lo que hacemos. En Liminal-Lab reivindicamos el derecho y la obligación de disfrutar.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'text1', 'text1', 'publish', 'closed', 'closed', '', 'field_602523d1aa26e', '', '', '2021-02-11 15:25:10', '2021-02-11 13:25:10', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&#038;p=32', 0, 'acf-field', '', 0),
(33, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:719:"Cómo y qué vas a conseguir\r\n\r\nDiagnosticar a través de un método simple y preciso el talento, habilidades, motivaciones y puntos fuertes de las personas, las flaquezas colectivas y los puntos ciegos inadvertidos.\r\n\r\nPotenciar el autoconocimiento y cruzarlo con la realidad de los entornos profesionales para promover el empoderamiento en la toma de decisiones y la integración en los equipos. \r\n\r\nConsolidar el equilibrio, la armonía y la eficiencia a través de esa nueva información sobre los perfiles del equipo.  \r\n\r\nRelanzar el diálogo orgánico entre talento y función profesional \r\n\r\nDiseñar un itinerario y acompañar durante el proceso para agilizarlo y verificar su rentabilidad y eficaz desarrollo.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'text2', 'text2', 'publish', 'closed', 'closed', '', 'field_602523e4aa26f', '', '', '2021-02-11 14:55:51', '2021-02-11 12:55:51', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&#038;p=33', 1, 'acf-field', '', 0),
(34, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:33:"OPTIMIZAR  LA GESTIÓN DE EQUIPOS";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'circle1', 'circle1', 'publish', 'closed', 'closed', '', 'field_6025242caa270', '', '', '2021-02-11 14:36:10', '2021-02-11 12:36:10', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=34', 2, 'acf-field', '', 0),
(35, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:42:"POTENCIAR LAS CAPACIDADES DE  LAS PERSONAS";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'circle2', 'circle2', 'publish', 'closed', 'closed', '', 'field_6025243eaa271', '', '', '2021-02-11 14:36:10', '2021-02-11 12:36:10', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=35', 3, 'acf-field', '', 0),
(36, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:44:"REALIZARNOS\r\nCRECER\r\nACEPTARNOS\r\n\r\nDISFRUTAR";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'circle3', 'circle3', 'publish', 'closed', 'closed', '', 'field_6025245daa272', '', '', '2021-02-11 14:36:10', '2021-02-11 12:36:10', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=36', 4, 'acf-field', '', 0),
(37, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:43:"FAVORECER LA EFICIENCIA DE LA ORGANIZACIÓN";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'circle4', 'circle4', 'publish', 'closed', 'closed', '', 'field_60252485aa273', '', '', '2021-02-11 14:36:10', '2021-02-11 12:36:10', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=37', 5, 'acf-field', '', 0),
(38, 1, '2021-02-11 14:36:10', '2021-02-11 12:36:10', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:42:"RENTABILIZAR  LA INVERSIÓN EN  EL TALENTO";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'circle5', 'circle5', 'publish', 'closed', 'closed', '', 'field_60252494aa274', '', '', '2021-02-11 14:36:10', '2021-02-11 12:36:10', '', 31, 'http://localhost:81/Liminal%20Lab/?post_type=acf-field&p=38', 6, 'acf-field', '', 0),
(40, 1, '2021-02-11 14:53:16', '2021-02-11 12:53:16', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:18:"page-servicios.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Servicios', 'servicios', 'publish', 'closed', 'closed', '', 'group_602528b78ab4a', '', '', '2021-02-12 14:05:38', '2021-02-12 12:05:38', '', 0, 'http://localhost:81/LiminalLab/?post_type=acf-field-group&#038;p=40', 0, 'acf-field-group', '', 0),
(41, 1, '2021-02-11 14:54:17', '2021-02-11 12:54:17', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"page-sobre-mi.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Sobre mí', 'sobre-mi', 'publish', 'closed', 'closed', '', 'group_602528f52b101', '', '', '2021-02-12 15:32:39', '2021-02-12 13:32:39', '', 0, 'http://localhost:81/LiminalLab/?post_type=acf-field-group&#038;p=41', 0, 'acf-field-group', '', 0),
(42, 1, '2021-02-11 14:57:17', '2021-02-11 12:57:17', '<!-- wp:paragraph -->\n<p>page para qué</p>\n<!-- /wp:paragraph -->', 'PARA QUÉ', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-02-11 14:57:17', '2021-02-11 12:57:17', '', 7, 'http://localhost:81/LiminalLab/7-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2021-02-11 14:58:12', '2021-02-11 12:58:12', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"page-contacto.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Contacto', 'contacto', 'publish', 'closed', 'closed', '', 'group_602529da9290d', '', '', '2021-02-12 17:46:34', '2021-02-12 15:46:34', '', 0, 'http://localhost:81/LiminalLab/?post_type=acf-field-group&#038;p=43', 0, 'acf-field-group', '', 0),
(44, 1, '2021-02-11 14:58:28', '2021-02-11 12:58:28', '', 'PARA QUÉ', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2021-02-11 14:58:28', '2021-02-11 12:58:28', '', 7, 'http://localhost:81/LiminalLab/7-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2021-02-11 15:20:52', '2021-02-11 13:20:52', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:346:"Servicios. Proponemos dos procesos que se adaptan a distintas necesidades. Los cambios de paradigma de la sociedad actual precisan herramientas y procesos que afloren la información, incentiven la creatividad de los equipos de trabajo e innoven en la forma de afrontar los retos y objetivos tanto de los profesionales como de las organizaciones.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'text1', 'text1', 'publish', 'closed', 'closed', '', 'field_60252f2486733', '', '', '2021-02-11 15:25:32', '2021-02-11 13:25:32', '', 40, 'http://localhost:81/LiminalLab/?post_type=acf-field&#038;p=45', 0, 'acf-field', '', 0),
(46, 1, '2021-02-11 15:21:36', '2021-02-11 13:21:36', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:31:"SÉ EL DUEÑO DE TUS DECISIONES";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'text_circle', 'text_circle', 'publish', 'closed', 'closed', '', 'field_60252f454ff3d', '', '', '2021-02-11 15:21:36', '2021-02-11 13:21:36', '', 40, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=46', 1, 'acf-field', '', 0),
(47, 1, '2021-02-11 15:23:09', '2021-02-11 13:23:09', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'text_slider', 'text_slider', 'publish', 'closed', 'closed', '', 'field_60252f70a6d4e', '', '', '2021-02-11 15:23:09', '2021-02-11 13:23:09', '', 40, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=47', 2, 'acf-field', '', 0),
(48, 1, '2021-02-11 15:23:09', '2021-02-11 13:23:09', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:740:"1. Liminal inception\r\n\r\nCómo evolucionar y disfrutar del itinerario y de una carrera profesional.\r\nCómo pasar del desencanto a encontrar tu lugar y crecer profesionalmente.\r\n \r\n¿Cuál es tu perfil de conducta natural y cómo te adaptas al entorno laboral? \r\n¿Qué es lo que se te da mejor y qué te cuesta más? \r\n¿Qué te motiva y qué no te va nada? \r\n¿A qué le deberías dedicar mayor atención y esfuerzo?\r\n\r\nObtén información para enfocar tu carrera y disfrutar del trayecto. Para aquellos jóvenes profesionales que iniciáis vuestra andadura laboral. Tanto si habéis finalizado vuestros estudios y aún no trabajáis, como si vivís vuestras primeras experiencias laborales, dentro de una organización o por cuenta propia.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'text', 'text', 'publish', 'closed', 'closed', '', 'field_60252f85a6d4f', '', '', '2021-02-11 15:25:44', '2021-02-11 13:25:44', '', 47, 'http://localhost:81/LiminalLab/?post_type=acf-field&#038;p=48', 0, 'acf-field', '', 0),
(49, 1, '2021-02-11 15:24:02', '2021-02-11 13:24:02', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:456:"SOBRE MI. Me apasionan la estrategia, la comunicación, la creatividad y sobretodo los equipos y las organizaciones. Tras más de 30 años de carrera profesional en agencias multinacionales de publicidad he trabajado para grandes marcas como Nestlé, Unilever, Mondelez, Deutsche Bank y Reckitt Benckiser, entre otras. Los últimos 20 años de mi carrera en agencias he dirigido equipos y liderado organizaciones formando parte de los boards de dirección.";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'text1', 'text1', 'publish', 'closed', 'closed', '', 'field_60252fd3f78b5', '', '', '2021-02-11 15:25:56', '2021-02-11 13:25:56', '', 41, 'http://localhost:81/LiminalLab/?post_type=acf-field&#038;p=49', 0, 'acf-field', '', 0),
(50, 1, '2021-02-11 15:24:43', '2021-02-11 13:24:43', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:87:"Contacto\r\nC/ Aribau 234 1er 2na\r\n08567 Barcelona \r\ninfo@liminallab.com\r\n+34 678 899 345";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:7:"wpautop";}', 'text1', 'text1', 'publish', 'closed', 'closed', '', 'field_60252fffea7d8', '', '', '2021-02-11 15:24:43', '2021-02-11 13:24:43', '', 43, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=50', 0, 'acf-field', '', 0),
(51, 1, '2021-02-11 15:26:56', '2021-02-11 13:26:56', '', 'SERVICIOS', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2021-02-11 15:26:56', '2021-02-11 13:26:56', '', 9, 'http://localhost:81/LiminalLab/9-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2021-02-12 13:51:38', '2021-02-12 11:51:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:45:"Repensar organizaciones y equipos para potenc";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'marquee', 'marquee', 'publish', 'closed', 'closed', '', 'field_60266b9f6322c', '', '', '2021-02-12 13:51:38', '2021-02-12 11:51:38', '', 31, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=52', 7, 'acf-field', '', 0),
(53, 1, '2021-02-12 13:54:09', '0000-00-00 00:00:00', '', 'Esborrany automàtic', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-02-12 13:54:09', '0000-00-00 00:00:00', '', 0, 'http://localhost:81/LiminalLab/?page_id=53', 0, 'page', '', 0),
(54, 1, '2021-02-12 14:07:01', '2021-02-12 12:07:01', '', 'PARA QUÉ', '', 'publish', 'closed', 'closed', '', 'para-que', '', '', '2021-02-12 15:09:12', '2021-02-12 13:09:12', '', 0, 'http://localhost:81/LiminalLab/?page_id=54', 1, 'page', '', 0),
(55, 1, '2021-02-12 14:07:01', '2021-02-12 12:07:01', '', 'PARA QUÉ', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2021-02-12 14:07:01', '2021-02-12 12:07:01', '', 54, 'http://localhost:81/LiminalLab/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2021-02-12 14:07:54', '2021-02-12 12:07:54', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2021-02-12 14:18:45', '2021-02-12 12:18:45', '', 0, 'http://localhost:81/LiminalLab/?p=56', 2, 'nav_menu_item', '', 0),
(57, 1, '2021-02-12 15:08:34', '2021-02-12 13:08:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:59:"Las metas se consiguen, sobre todo, si disfrutas del camino";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'marquee2', 'marquee2', 'publish', 'closed', 'closed', '', 'field_60267dc207360', '', '', '2021-02-12 15:08:34', '2021-02-12 13:08:34', '', 31, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=57', 8, 'acf-field', '', 0),
(58, 1, '2021-02-12 15:09:12', '2021-02-12 13:09:12', '', 'PARA QUÉ', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2021-02-12 15:09:12', '2021-02-12 13:09:12', '', 54, 'http://localhost:81/LiminalLab/54-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2021-02-12 15:32:39', '2021-02-12 13:32:39', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:1:"#";s:11:"placeholder";s:0:"";}', 'link', 'link', 'publish', 'closed', 'closed', '', 'field_6026833d4bd1e', '', '', '2021-02-12 15:32:39', '2021-02-12 13:32:39', '', 41, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=59', 1, 'acf-field', '', 0),
(60, 1, '2021-02-12 17:46:34', '2021-02-12 15:46:34', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:1:"#";s:11:"placeholder";s:0:"";}', 'instagram', 'instagram', 'publish', 'closed', 'closed', '', 'field_6026a292b640a', '', '', '2021-02-12 17:46:34', '2021-02-12 15:46:34', '', 43, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=60', 1, 'acf-field', '', 0),
(61, 1, '2021-02-12 17:46:34', '2021-02-12 15:46:34', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:1:"#";s:11:"placeholder";s:0:"";}', 'facebook', 'facebook', 'publish', 'closed', 'closed', '', 'field_6026a2a9b640b', '', '', '2021-02-12 17:46:34', '2021-02-12 15:46:34', '', 43, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=61', 2, 'acf-field', '', 0),
(62, 1, '2021-02-12 17:46:34', '2021-02-12 15:46:34', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:1:"#";s:11:"placeholder";s:0:"";}', 'linkedin', 'linkedin', 'publish', 'closed', 'closed', '', 'field_6026a2b3b640c', '', '', '2021-02-12 17:46:34', '2021-02-12 15:46:34', '', 43, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=62', 3, 'acf-field', '', 0),
(63, 1, '2021-02-12 17:46:34', '2021-02-12 15:46:34', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:1:"#";s:11:"placeholder";s:0:"";}', 'twitter', 'twitter', 'publish', 'closed', 'closed', '', 'field_6026a2c1b640d', '', '', '2021-02-12 17:46:34', '2021-02-12 15:46:34', '', 43, 'http://localhost:81/LiminalLab/?post_type=acf-field&p=63', 4, 'acf-field', '', 0),
(64, 1, '2021-02-12 17:47:55', '2021-02-12 15:47:55', '', 'CONTACTO', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2021-02-12 17:47:55', '2021-02-12 15:47:55', '', 13, 'http://localhost:81/LiminalLab/13-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2021-02-12 18:50:48', '2021-02-12 16:50:48', '', 'Textos legales', '', 'publish', 'closed', 'closed', '', 'textos-legales', '', '', '2021-02-12 18:50:48', '2021-02-12 16:50:48', '', 0, 'http://localhost:81/LiminalLab/?page_id=65', 0, 'page', '', 0),
(66, 1, '2021-02-12 18:50:48', '2021-02-12 16:50:48', '', 'Textos legales', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2021-02-12 18:50:48', '2021-02-12 16:50:48', '', 65, 'http://localhost:81/LiminalLab/65-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(17, 2, 0),
(18, 2, 0),
(20, 2, 0),
(21, 2, 0),
(56, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 5) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'General', 'general', 0),
(2, 'Main Menu', 'main-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"a457093adc56210165b719a5bb30220905caa8d8c9855631cab89345b6132cf2";a:4:{s:10:"expiration";i:1613556171;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 11_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36";s:5:"login";i:1613383371;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:5:{i:0;s:25:"add-post-type-custom_type";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";i:3;s:14:"add-custom_cat";i:4;s:14:"add-custom_tag";}'),
(21, 1, 'nav_menu_recently_edited', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BIB0YcZGpldwUmxAwkjCc9a8eZdQVc/', 'admin', 'joan.parellada@maneko.es', 'http://localhost:81/Liminal%20Lab', '2021-02-11 11:43:49', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

